import re

def extract_episode_number(text: str | None) -> int | None:
    if not text:
        return None
    patterns = [
        r"(?i)\b(\d+)\s*[- ]?\s*qism\b",
        r"(?i)\bep(?:isode)?\.?\s*[- ]?(\d+)\b",
        r"(?i)^\s*(\d+)\s*$",
    ]
    for pattern in patterns:
        m = re.search(pattern, text)
        if m:
            return int(m.group(1))
    return None

def format_description(template: str, anime_name: str, episode: int) -> str:
    return template.replace("{anime_name}", anime_name).replace("{episode}", str(episode))
