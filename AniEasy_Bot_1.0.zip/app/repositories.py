from datetime import datetime
from sqlalchemy import select, func, delete
from sqlalchemy.ext.asyncio import AsyncSession
from app.models import Anime, Episode, User, Favorite, WatchProgress

async def get_or_create_user(session, tg_user):
    result = await session.execute(select(User).where(User.telegram_id == tg_user.id))
    user = result.scalar_one_or_none()
    if not user:
        user = User(telegram_id=tg_user.id, username=tg_user.username, first_name=tg_user.first_name)
        session.add(user)
    user.username = tg_user.username
    user.first_name = tg_user.first_name
    user.last_active = datetime.utcnow()
    await session.commit()
    return user

async def create_anime(session, title, description=None):
    anime = Anime(title=title, description=description)
    session.add(anime)
    await session.commit()
    await session.refresh(anime)
    return anime

async def get_anime(session, anime_id):
    return await session.get(Anime, anime_id)

async def list_animes(session, limit=10, offset=0):
    result = await session.execute(select(Anime).order_by(Anime.id.desc()).offset(offset).limit(limit))
    return list(result.scalars())

async def search_animes(session, query, limit=20):
    q = f"%{query}%"
    result = await session.execute(select(Anime).where((Anime.title.ilike(q)) | (Anime.alternate_title.ilike(q))).limit(limit))
    return list(result.scalars())

async def get_episode(session, anime_id, ep):
    result = await session.execute(select(Episode).where(Episode.anime_id == anime_id, Episode.episode_number == ep))
    return result.scalar_one_or_none()

async def upsert_episode(session, anime_id, ep, file_id, file_unique_id, caption):
    old = await get_episode(session, anime_id, ep)
    if old:
        old.telegram_file_id = file_id
        old.file_unique_id = file_unique_id
        old.caption = caption
        await session.commit()
        return old, True
    item = Episode(anime_id=anime_id, episode_number=ep, telegram_file_id=file_id, file_unique_id=file_unique_id, caption=caption)
    session.add(item)
    await session.commit()
    await session.refresh(item)
    return item, False

async def list_episodes(session, anime_id):
    result = await session.execute(select(Episode).where(Episode.anime_id == anime_id).order_by(Episode.episode_number))
    return list(result.scalars())

async def count_animes(session):
    return await session.scalar(select(func.count(Anime.id)))

async def count_episodes(session):
    return await session.scalar(select(func.count(Episode.id)))

async def count_users(session):
    return await session.scalar(select(func.count(User.id)))

async def increment_views(session, episode):
    episode.views += 1
    await session.commit()

async def toggle_favorite(session, telegram_id, anime_id):
    result = await session.execute(select(User).where(User.telegram_id == telegram_id))
    user = result.scalar_one()
    result = await session.execute(select(Favorite).where(Favorite.user_id == user.id, Favorite.anime_id == anime_id))
    fav = result.scalar_one_or_none()
    if fav:
        await session.delete(fav)
        await session.commit()
        return False
    session.add(Favorite(user_id=user.id, anime_id=anime_id))
    await session.commit()
    return True

async def save_progress(session, telegram_id, anime_id, ep):
    user = (await session.execute(select(User).where(User.telegram_id == telegram_id))).scalar_one()
    result = await session.execute(select(WatchProgress).where(WatchProgress.user_id == user.id, WatchProgress.anime_id == anime_id))
    item = result.scalar_one_or_none()
    if item:
        item.episode_number = ep
        item.updated_at = datetime.utcnow()
    else:
        session.add(WatchProgress(user_id=user.id, anime_id=anime_id, episode_number=ep))
    await session.commit()
