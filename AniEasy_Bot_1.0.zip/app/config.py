from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class Settings(BaseSettings):
    bot_token: str = Field(alias="BOT_TOKEN")
    admin_ids: str = Field(default="", alias="ADMIN_IDS")
    owner_id: int = Field(default=0, alias="OWNER_ID")
    database_url: str = Field(default="sqlite+aiosqlite:///./data/anibot.db", alias="DATABASE_URL")
    channel_id: str = Field(default="", alias="CHANNEL_ID")
    log_channel_id: str = Field(default="", alias="LOG_CHANNEL_ID")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    episodes_per_page: int = Field(default=10, alias="EPISODES_PER_PAGE")
    description_template: str = Field(default="🎬 {anime_name}\n📺 {episode}-qism", alias="DESCRIPTION_TEMPLATE")

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def admins(self) -> set[int]:
        result = set()
        for x in self.admin_ids.split(","):
            x = x.strip()
            if x.isdigit():
                result.add(int(x))
        if self.owner_id:
            result.add(self.owner_id)
        return result

settings = Settings()
