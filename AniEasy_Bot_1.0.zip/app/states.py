from aiogram.fsm.state import State, StatesGroup

class AddAnime(StatesGroup):
    title = State()
    description = State()
    upload = State()

class SearchState(StatesGroup):
    query = State()

class BroadcastState(StatesGroup):
    text = State()

class EditAnime(StatesGroup):
    title = State()
    description = State()
