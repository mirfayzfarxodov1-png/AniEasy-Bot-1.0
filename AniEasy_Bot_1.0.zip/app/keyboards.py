from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

def main_menu(is_admin=False):
    rows = [
        [KeyboardButton(text="🎬 Anime"), KeyboardButton(text="🔎 Qidirish")],
        [KeyboardButton(text="⭐ Sevimlilar"), KeyboardButton(text="🆕 Yangi qo'shilganlar")],
        [KeyboardButton(text="ℹ️ Yordam")],
    ]
    if is_admin:
        rows.append([KeyboardButton(text="👑 Admin panel")])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)

def admin_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Anime qo'shish", callback_data="admin:add")],
        [InlineKeyboardButton(text="📚 Anime ro'yxati", callback_data="admin:list")],
        [InlineKeyboardButton(text="📊 Statistika", callback_data="admin:stats")],
        [InlineKeyboardButton(text="📢 Xabar yuborish", callback_data="admin:broadcast")],
        [InlineKeyboardButton(text="⚙️ Sozlamalar", callback_data="admin:settings")],
    ])

def cancel_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="cancel")]
    ])

def finish_upload_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏭ Yakunlash", callback_data="upload:finish")],
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="cancel")],
    ])

def anime_kb(anime_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📺 Qismlar", callback_data=f"anime:{anime_id}:episodes")],
        [InlineKeyboardButton(text="⭐ Sevimli", callback_data=f"fav:{anime_id}")],
    ])

def episode_nav(anime_id: int, prev_ep: int | None, next_ep: int | None):
    row=[]
    if prev_ep is not None:
        row.append(InlineKeyboardButton(text=f"⬅️ {prev_ep}-qism", callback_data=f"ep:{anime_id}:{prev_ep}"))
    row.append(InlineKeyboardButton(text="🏠 Anime", callback_data=f"anime:{anime_id}:episodes"))
    if next_ep is not None:
        row.append(InlineKeyboardButton(text=f"{next_ep}-qism ➡️", callback_data=f"ep:{anime_id}:{next_ep}"))
    return InlineKeyboardMarkup(inline_keyboard=[row])
