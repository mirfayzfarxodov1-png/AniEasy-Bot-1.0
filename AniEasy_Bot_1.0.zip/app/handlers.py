import logging
from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select

from app.db import SessionLocal
from app.config import settings
from app.models import Anime, Episode, User
from app.states import AddAnime, SearchState, BroadcastState
from app.keyboards import main_menu, admin_menu, cancel_kb, finish_upload_kb, anime_kb, episode_nav
from app.repositories import *
from app.utils import extract_episode_number, format_description

router = Router()
log = logging.getLogger(__name__)

async def is_admin(user_id: int) -> bool:
    return user_id in settings.admins

@router.message(CommandStart())
async def start(message: Message):
    async with SessionLocal() as session:
        await get_or_create_user(session, message.from_user)
    admin = await is_admin(message.from_user.id)
    await message.answer(
        "🎬 <b>AniEasy Bot 1.0</b>\n\n"
        "Anime topish va qismlarni qulay ko'rish uchun xush kelibsiz!",
        reply_markup=main_menu(admin)
    )

@router.message(F.text == "👑 Admin panel")
async def admin_panel(message: Message):
    if not await is_admin(message.from_user.id):
        return await message.answer("❌ Sizda admin huquqi yo'q.")
    await message.answer("👑 <b>Admin panel</b>", reply_markup=admin_menu())

@router.callback_query(F.data == "admin:add")
async def add_start(call: CallbackQuery, state: FSMContext):
    if not await is_admin(call.from_user.id):
        return await call.answer("Ruxsat yo'q", show_alert=True)
    await state.set_state(AddAnime.title)
    await call.message.answer("🎬 Anime nomini yuboring:", reply_markup=cancel_kb())
    await call.answer()

@router.message(AddAnime.title)
async def add_title(message: Message, state: FSMContext):
    await state.update_data(title=message.text.strip())
    await state.set_state(AddAnime.description)
    await message.answer("📝 Anime tavsifini yuboring yoki <code>-</code> yozing:")

@router.message(AddAnime.description)
async def add_description(message: Message, state: FSMContext):
    desc = None if message.text.strip() == "-" else message.text.strip()
    data = await state.get_data()
    async with SessionLocal() as session:
        anime = await create_anime(session, data["title"], desc)
    await state.update_data(anime_id=anime.id, next_episode=1)
    await state.set_state(AddAnime.upload)
    await message.answer(
        f"✅ <b>{anime.title}</b> yaratildi.\n\n"
        "Endi videolarni ketma-ket yuboring.\n"
        "Caption bo'lmasa: 1-video = 1-qism, 2-video = 2-qism...\n\n"
        "Tugatgach «⏭ Yakunlash»ni bosing.",
        reply_markup=finish_upload_kb()
    )

@router.message(AddAnime.upload, F.video)
async def upload_episode(message: Message, state: FSMContext):
    data = await state.get_data()
    anime_id = data["anime_id"]
    next_ep = int(data.get("next_episode", 1))
    caption = message.caption or ""
    detected = extract_episode_number(caption)
    ep = detected if detected is not None else next_ep

    async with SessionLocal() as session:
        anime = await get_anime(session, anime_id)
        if not anime:
            await state.clear()
            return await message.answer("❌ Anime topilmadi.")
        item, replaced = await upsert_episode(
            session, anime_id, ep, message.video.file_id, message.video.file_unique_id, caption
        )

    await state.update_data(next_episode=max(next_ep, ep + 1))
    action = "yangilandi" if replaced else "qabul qilindi"
    await message.answer(
        f"✅ {ep}-qism {action}.\n"
        f"➡️ Keyingi: {max(next_ep, ep + 1)}-qism",
        reply_markup=finish_upload_kb()
    )

@router.message(AddAnime.upload)
async def upload_nonvideo(message: Message):
    await message.answer("⚠️ Iltimos, video fayl yuboring yoki «⏭ Yakunlash»ni bosing.", reply_markup=finish_upload_kb())

@router.callback_query(F.data == "upload:finish")
async def finish_upload(call: CallbackQuery, state: FSMContext):
    if not await is_admin(call.from_user.id):
        return await call.answer("Ruxsat yo'q", show_alert=True)
    data = await state.get_data()
    anime_id = data.get("anime_id")
    async with SessionLocal() as session:
        anime = await get_anime(session, anime_id)
        episodes = await list_episodes(session, anime_id)
    if not anime:
        await state.clear()
        return await call.message.answer("❌ Anime topilmadi.")
    nums = [x.episode_number for x in episodes]
    missing = []
    if nums:
        for n in range(1, max(nums) + 1):
            if n not in nums:
                missing.append(n)
    text = f"🎉 <b>Yuklash yakunlandi!</b>\n\n🎬 {anime.title}\n📺 Jami: {len(episodes)} qism"
    if missing:
        text += "\n\n⚠️ Yetishmayotgan qismlar: " + ", ".join(map(str, missing))
    await state.clear()
    await call.message.answer(text, reply_markup=admin_menu())
    await call.answer()

@router.callback_query(F.data == "admin:list")
async def admin_list(call: CallbackQuery):
    if not await is_admin(call.from_user.id):
        return await call.answer("Ruxsat yo'q", show_alert=True)
    async with SessionLocal() as session:
        animes = await list_animes(session, 20)
    if not animes:
        return await call.message.answer("📭 Hozircha anime yo'q.")
    lines = ["📚 <b>Anime ro'yxati</b>\n"]
    for a in animes:
        async with SessionLocal() as session:
            eps = await list_episodes(session, a.id)
        lines.append(f"🎬 <b>{a.title}</b> — {len(eps)} qism")
    await call.message.answer("\n".join(lines))
    await call.answer()

@router.callback_query(F.data == "admin:stats")
async def stats(call: CallbackQuery):
    if not await is_admin(call.from_user.id):
        return await call.answer("Ruxsat yo'q", show_alert=True)
    async with SessionLocal() as session:
        users = await count_users(session)
        animes = await count_animes(session)
        eps = await count_episodes(session)
    await call.message.answer(f"📊 <b>Statistika</b>\n\n👥 Foydalanuvchilar: {users}\n🎬 Anime: {animes}\n📺 Qismlar: {eps}")
    await call.answer()

@router.callback_query(F.data.startswith("anime:"))
async def anime_callback(call: CallbackQuery):
    _, anime_id, action = call.data.split(":")
    anime_id = int(anime_id)
    async with SessionLocal() as session:
        anime = await get_anime(session, anime_id)
        episodes = await list_episodes(session, anime_id)
    if not anime:
        return await call.answer("Anime topilmadi", show_alert=True)
    if action == "episodes":
        if not episodes:
            return await call.message.answer("📭 Bu anime uchun qism yo'q.")
        buttons=[]
        for ep in episodes[:settings.episodes_per_page]:
            buttons.append([__import__("aiogram").types.InlineKeyboardButton(text=f"📺 {ep.episode_number}-qism", callback_data=f"ep:{anime_id}:{ep.episode_number}")])
        await call.message.answer(f"🎬 <b>{anime.title}</b>\n📺 Jami: {len(episodes)} qism", reply_markup=__import__("aiogram").types.InlineKeyboardMarkup(inline_keyboard=buttons))
    await call.answer()

@router.callback_query(F.data.startswith("ep:"))
async def episode_callback(call: CallbackQuery):
    _, anime_id, ep = call.data.split(":")
    anime_id, ep = int(anime_id), int(ep)
    async with SessionLocal() as session:
        anime = await get_anime(session, anime_id)
        episode = await get_episode(session, anime_id, ep)
        episodes = await list_episodes(session, anime_id)
        if episode:
            await increment_views(session, episode)
            await save_progress(session, call.from_user.id, anime_id, ep)
    if not anime or not episode:
        return await call.answer("Qism topilmadi", show_alert=True)
    nums = [x.episode_number for x in episodes]
    prev_ep = max([x for x in nums if x < ep], default=None)
    next_ep = min([x for x in nums if x > ep], default=None)
    caption = format_description(settings.description_template, anime.title, ep)
    await call.message.answer_video(episode.telegram_file_id, caption=caption, reply_markup=episode_nav(anime_id, prev_ep, next_ep))
    await call.answer()

@router.callback_query(F.data.startswith("fav:"))
async def favorite_callback(call: CallbackQuery):
    anime_id = int(call.data.split(":")[1])
    async with SessionLocal() as session:
        await get_or_create_user(session, call.from_user)
        added = await toggle_favorite(session, call.from_user.id, anime_id)
    await call.answer("⭐ Sevimlilarga qo'shildi" if added else "⭐ Sevimlilardan olib tashlandi")

@router.message(F.text == "🎬 Anime")
async def all_anime(message: Message):
    async with SessionLocal() as session:
        animes = await list_animes(session, 20)
    if not animes:
        return await message.answer("📭 Hozircha anime mavjud emas.")
    for a in animes:
        await message.answer(f"🎬 <b>{a.title}</b>\n\n{a.description or ''}", reply_markup=anime_kb(a.id))

@router.message(F.text == "🔎 Qidirish")
async def search_start(message: Message, state: FSMContext):
    await state.set_state(SearchState.query)
    await message.answer("🔎 Anime nomini yozing:")

@router.message(SearchState.query)
async def search_do(message: Message, state: FSMContext):
    async with SessionLocal() as session:
        results = await search_animes(session, message.text.strip())
    await state.clear()
    if not results:
        return await message.answer("🔎 Hech narsa topilmadi.")
    for a in results:
        await message.answer(f"🎬 <b>{a.title}</b>", reply_markup=anime_kb(a.id))

@router.message(F.text == "ℹ️ Yordam")
async def help_msg(message: Message):
    await message.answer(
        "ℹ️ <b>Yordam</b>\n\n"
        "🎬 Anime — anime ro'yxati\n"
        "🔎 Qidirish — nom bo'yicha qidirish\n"
        "⭐ Sevimlilar — saqlangan anime\n\n"
        "Muammo bo'lsa admin bilan bog'laning."
    )

@router.callback_query(F.data == "cancel")
async def cancel(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.answer("❌ Amal bekor qilindi.", reply_markup=admin_menu() if await is_admin(call.from_user.id) else None)
    await call.answer()

@router.callback_query(F.data == "admin:broadcast")
async def broadcast_start(call: CallbackQuery, state: FSMContext):
    if not await is_admin(call.from_user.id):
        return await call.answer("Ruxsat yo'q", show_alert=True)
    await state.set_state(BroadcastState.text)
    await call.message.answer("📢 Yuboriladigan xabar matnini yuboring:", reply_markup=cancel_kb())
    await call.answer()

@router.message(BroadcastState.text)
async def broadcast_do(message: Message, state: FSMContext):
    async with SessionLocal() as session:
        result = await session.execute(select(User.telegram_id))
        ids = list(result.scalars())
    ok = 0
    for uid in ids:
        try:
            await message.bot.send_message(uid, message.text)
            ok += 1
        except Exception:
            pass
    await state.clear()
    await message.answer(f"📢 Yuborish yakunlandi.\n✅ Yetkazildi: {ok}\n👥 Jami: {len(ids)}", reply_markup=admin_menu())

@router.callback_query(F.data == "admin:settings")
async def settings_page(call: CallbackQuery):
    if not await is_admin(call.from_user.id):
        return await call.answer("Ruxsat yo'q", show_alert=True)
    await call.message.answer(
        "⚙️ <b>Sozlamalar</b>\n\n"
        f"📄 Description template:\n<code>{settings.description_template}</code>\n\n"
        f"📺 Sahifadagi qism: {settings.episodes_per_page}"
    )
    await call.answer()
