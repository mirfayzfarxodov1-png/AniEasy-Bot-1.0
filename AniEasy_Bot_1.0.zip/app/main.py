import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from app.config import settings
from app.db import init_db
from app.handlers import router
from app.logging_config import setup_logging

async def main():
    setup_logging()
    log = logging.getLogger(__name__)
    await init_db()

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    dp = Dispatcher()
    dp.include_router(router)

    log.info("AniEasy Bot 1.0 ishga tushmoqda")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
