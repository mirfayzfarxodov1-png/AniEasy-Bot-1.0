from app.utils import extract_episode_number

def test_episode():
    assert extract_episode_number("7-qism") == 7
    assert extract_episode_number("12") == 12
    assert extract_episode_number("Anime 24-qism") == 24
    assert extract_episode_number("hello") is None
