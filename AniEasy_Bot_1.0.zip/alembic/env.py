# Minimal Alembic bootstrap. For production migrations, import app.models and configure
# target_metadata = Base.metadata.
from app.db import Base
from app.models import Anime, Episode, User, Favorite, WatchProgress
target_metadata = Base.metadata
