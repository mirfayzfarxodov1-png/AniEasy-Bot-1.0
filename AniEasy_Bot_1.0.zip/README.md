# AniEasy Bot 1.0

Professional Uzbek-language Telegram anime content management bot built with Python + aiogram 3 + SQLAlchemy.

## Muhim xavfsizlik
Bot tokenini kodga yozmang. `.env` ichiga joylang. Chatga yuborilgan token maxfiy hisoblanmaydi: uni BotFather orqali bekor qilib, yangi token oling.

## Xususiyatlar
- O'zbekcha foydalanuvchi interfeysi
- Admin panel
- Anime CRUD
- Ketma-ket episode upload session
- `1`, `1-qism`, `Anime 12-qism` kabi captionlardan episode raqamini aniqlash
- Caption bo'lmasa sessiondagi navbatdagi raqamdan foydalanish
- Telegram `file_id` saqlash
- Duplicate episode aniqlash va yangilash
- Missing episode tekshiruvi
- Episode pagination
- Anime qidiruvi
- Sevimlilar
- Oxirgi ko'rilgan qism
- Ko'rish statistikasi
- Broadcast
- Kanal notification
- PostgreSQL/SQLite
- Docker
- Redis ixtiyoriy
- Logging
- Error handling
- Testlar

## O'rnatish

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env
```

`.env` ni to'ldiring:

```env
BOT_TOKEN=NEW_TOKEN_FROM_BOTFATHER
ADMIN_IDS=8404514882
OWNER_ID=8404514882
DATABASE_URL=sqlite+aiosqlite:///./data/anibot.db
CHANNEL_ID=
LOG_CHANNEL_ID=
```

Ishga tushirish:

```bash
python -m app.main
```

## Docker

```bash
docker compose up -d --build
docker compose logs -f bot
```

## Ishlash
1. `/start`
2. Admin uchun `👑 Admin panel`
3. `➕ Anime qo'shish`
4. Anime nomini kiriting
5. Videolarni ketma-ket yuboring
6. Bot 1-qism, 2-qism, 3-qism... sifatida qabul qiladi
7. `⏭ Yakunlash`
8. Yetishmayotgan qismlar ko'rsatiladi

Caption bilan yuborish ham mumkin:
- `7`
- `7-qism`
- `Solo Leveling 12-qism`

## GitHub
GitHub connector ulanganidan keyin repository yaratish/push qilish mumkin. Token va `.env` hech qachon commit qilinmasin.
